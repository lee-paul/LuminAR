﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BundleDB
{
    public static readonly string BundleInputPath = "Assets/Prefabs/";          // Bundle input is under prefabs
#if UNITY_EDITOR                                                                            // In case of editor, streaming assets path is under folder "StreamingAssets",
    public static readonly string BundleOutputPath = "Assets/StreamingAssets/Bundles/";     // however, if we want to use them on devices too, we have to use
#else                                                                                       // Application.streamingAssets to get to that folder
    public static readonly string BundleOutputPath = Application.streamingAssetsPath + "/Bundles/"; 
#endif
    public static readonly List<KeyValuePair<string, string>> BundleInputOutputFilePairs;   // This List of pairs associated prefabs with bundles

    static BundleDB()
    {
        BundleInputOutputFilePairs = new List<KeyValuePair<string, string>>();

        BundleInputOutputFilePairs.Add(new KeyValuePair<string, string>("Sphere.prefab", "Sphere.bytes"));
        BundleInputOutputFilePairs.Add(new KeyValuePair<string, string>("Cube.prefab", "Cube.bytes"));
    }
}