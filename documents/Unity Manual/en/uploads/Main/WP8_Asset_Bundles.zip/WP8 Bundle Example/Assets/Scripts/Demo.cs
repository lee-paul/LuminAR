﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Demo : MonoBehaviour
{
    public int NumberOfRows = 2;                // Number of rows/columns of prefabs to instantiate from the bundle
    public int NumberOfColumns = 2;

    AssetBundle m_AssetBundle = null;           // Currently loaded bundle
    GameObject m_AssetPrefab = null;            // Currently loaded prefab
    List<GameObject> m_InstantiatedObjects = new List<GameObject>();       // List of instantiated objects. We need to store them to be able to destroy them before unload the bundle
    int level = 0;                              // Represents one of three possible game states

    void OnGUI()
    {
        var style = new GUIStyle();
        style.fontSize = 50;
        style.alignment = TextAnchor.UpperCenter;
        style.normal.textColor = Color.white;

        if (level > 0)
        {
            GUI.Label(new Rect(20, 20, Screen.width - 40, Screen.height - 40), "Level " + level.ToString(), style);

            // If user presses the button, bundle gets unloaded and a different one gets loaded
            if (GUI.Button(new Rect(Screen.width / 2 - 50, Screen.height / 2 - 20, 100, 40), "Go to Level " + (level == 1 ? 2 : 1).ToString()))
            {
                UnloadBundle();
                level = level == 1 ? 2 : 1;
                StartCoroutine(LoadBundle());       // Load bundle must be called via "StartCoroutine",
            }                                       // as it might take more than one frame to load the bundle
        }
        else
        {
            GUI.Label(new Rect(20, 20, Screen.width - 40, Screen.height - 40), "Unity Bundle Sample", style);

            // As a special case for beginning, our level number is 0 and we don't load anything until the user starts the demo
            if (GUI.Button(new Rect(Screen.width / 2 - 50, Screen.height / 2 - 20, 100, 40), "Start demo"))
            {
                level = 1;
                StartCoroutine(LoadBundle());
            }
        }
    }

    void UnloadBundle()
    {
        // We must destroy each object in scene before unloading the bundle
        foreach (var obj in m_InstantiatedObjects)
        {
            Destroy(obj);
        }

        m_InstantiatedObjects.Clear();
        m_AssetBundle.Unload(true);         // Always pass true to Unload(), the other mode is not supported on Windows Phone 8
        m_AssetBundle = null;
    }

    IEnumerator LoadBundle()
    {
        m_AssetBundle = AssetBundle.CreateFromFile(BundleDB.BundleOutputPath + BundleDB.BundleInputOutputFilePairs[level - 1].Value);

        // While the asset isn't loaded, yield nulls
        while (m_AssetBundle == null)
        {
            yield return null;
        }

        // The asset name is the same as prefab name, except for the file extension - that is "Sphere" instead of "Sphere.prefab"
        var assetName = BundleDB.BundleInputOutputFilePairs[level - 1].Key.Split('.')[0];
        m_AssetPrefab = m_AssetBundle.Load(assetName) as GameObject;

        // Once we got the prefab, spawn the objects
        SpawnObjects();
    }

    void SpawnObjects()
    {
        // Spawn all the objects in square center in middle of the screen
        // Use camera on convert screen coordinates to world coordinates
        var camera = GetComponent<Camera>();
        int rowStep = Screen.height / (2 * (NumberOfRows - 1));
        int columnStep = Screen.width / (2 * (NumberOfColumns - 1));

        for (int i = 0; i < NumberOfRows * NumberOfColumns; i++)
        {
            var positionOnScreen = new Vector3(Screen.width / 4 + (i % NumberOfColumns) * columnStep, Screen.height / 4 + (i / NumberOfColumns) * rowStep, -transform.position.z);
            var position = camera.ScreenToWorldPoint(positionOnScreen);

            m_InstantiatedObjects.Add(Instantiate(m_AssetPrefab, position, Quaternion.identity) as GameObject);
        }
    }
}
