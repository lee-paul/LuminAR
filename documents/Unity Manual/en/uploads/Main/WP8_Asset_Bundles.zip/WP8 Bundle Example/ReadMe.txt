WP8 Bundle Example is a project that shows how to use bundles on Windows Phone.

To run example project:
- Open Export\WP8BundleExample.sln solution with Visual Studio 2012
- Connect your phone to PC and make sure device is unlocked
- Build and run example project

WP8 Bundle Example app loads one bundle and spawns objects in middle of the screen based on a prefab from the bundle. The button in the middle switches between loading two bundles, one at a time, simulating switching game levels.