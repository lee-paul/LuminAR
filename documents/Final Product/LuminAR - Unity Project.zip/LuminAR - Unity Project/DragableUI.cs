﻿/*	Copyright 2015 Luminary Promotions
 *
 *	Licensed under the Apache License, Version 2.0 (the "License");
 *	you may not use this file except in compliance with the License.
 *	You may obtain a copy of the License at
 *
 *		http://www.apache.org/licenses/LICENSE-2.0
 *
 *	Unless required by applicable law or agreed to in writing, software
 *	distributed under the License is distributed on an "AS IS" BASIS,
 *	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *	See the License for the specific language governing permissions and limitations under the License.
 */

using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace Luminary.Unity.Utility {

	[RequireComponent (typeof (Button))]

	public class DragableUI : MonoBehaviour, IPointerDownHandler, IPointerUpHandler {

		#region PUBLIC_VARIABLES

		/// <summary>
		/// If this element is currently being dragged
		/// </summary>
		[Tooltip ("If this element is currently being dragged")]
		[SerializeField] private bool dragging;

		/// <summary>
		/// Methods to invoke when dragging stops
		/// </summary>
		[Tooltip ("Methods to invoke when dragging stops")]
		[SerializeField] private UnityEvent OnStopDragging;

		#endregion // PUBLIC_VARIABLES

		#region PRIVATE_VARIABLES

		/// <summary>
		///	Used when the image is created to wait for the mouse to be released and the image placed
		/// </summary>
		private bool waitForMouseUp;

		/// <summary>
		/// The offset from this transform to the mouse position when it was clicked,
		/// this avoids the image moving when it is selected
		/// </summary>
		private Vector3 mouseOffset;

		#endregion // PRIVATE_VARIABLES

		#region MONOBEHAVIOUR_METHODS

		/// <summary>
		/// Called every frame
		/// </summary>
		void Update () {
			Move ();
		}

		#endregion // MONOBEHAVIOUR_METHODS

		#region PUBLIC_METHODS

		/// <summary>
		/// Starts the dragging.
		/// </summary>
		public void StartDragging() {
			dragging = true;
			mouseOffset = transform.position - UnityEngine.Input.mousePosition;
		}
		
		/// <summary>
		/// Deselects the image.
		/// </summary>
		public void StopDragging() {
			dragging = false;

			if (OnStopDragging != null)
				OnStopDragging.Invoke();
		}

		#endregion // PUBLIC_METHODS
		
		#region PRIVATE_METHODS

		/// <summary>
		/// Raises the pointer down event.
		/// </summary>
		/// <param name="eventData">Event data.</param>
		public void OnPointerDown(PointerEventData eventData) {
			StartDragging();
		}

		public void OnPointerUp(PointerEventData eventData) {
			StopDragging();
		}

		/// <summary>
		/// Move the dragable
		/// </summary>
		private void Move() {
			if (dragging) {
				transform.position = UnityEngine.Input.mousePosition + mouseOffset;

				//Special check for when the object is created, need to wait for the mouse to be released 
				// and then stop dragging as unity does not think the image is being pressed
				if (/*waitForMouseUp &&*/ UnityEngine.Input.GetMouseButtonUp(0)) {
					//waitForMouseUp = false;
					StopDragging();
				}
			}
		}

		#endregion // PRIVATE_METHODS
	}
}