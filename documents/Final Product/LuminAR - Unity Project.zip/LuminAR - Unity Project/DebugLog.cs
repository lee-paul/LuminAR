﻿/* Copyright 2015 Alexis Rabadan

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.*/

using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace Luminary.Unity.Utility {

	/// <summary>
	/// Presents a debug log to the user
	/// </summary>
	public class DebugLog : MonoBehaviour {

		#region PUBLIC_VARIABLES

		[Header ("Log Display")]

		/// <summary>
		/// The bounds where we should display the log
		/// </summary>
		[Tooltip ("The bounds where we should display the log")]
		[SerializeField] private Rect bounds = new Rect(0f, 0f, 0.5f, 1f);

		/// <summary>
		/// The bound of the log
		/// </summary>
		[Tooltip ("The bound of the log")]
		[SerializeField] private Rect logBounds = new Rect(0f, 0f, 1f, 1f);
		
		/// <summary>
		/// The color of the background
		/// </summary>
		[Tooltip ("The color of the background")]
		[SerializeField] private Color  backgroundColor = new Color (0.2f, 0.2f, 0.2f, 0.5f);

		[Header ("Button Display")]

		/// <summary>
		/// The bounds to display for the button
		/// </summary>
		[Tooltip ("The bounds to display for the button")]
		[SerializeField] private Rect buttonBounds = new Rect(0.1f, 0.85f, 0.2f, 0.1f);

		/// <summary>
		/// The color of the button to display
		/// </summary>
		[Tooltip ("The color of the button to display")]
		[SerializeField] private Color buttonColor = new Color (0.05f, 0.05f, 0.05f, 0.75f);

		#endregion // PUBLIC_VARIABLES

		#region PRIVATE_VARIABLES

		private static Rect halfRect = new Rect(0.25f, 0.25f, 0.5f, 0.5f);

		/// <summary>
		/// The backgound for the log
		/// </summary>
		private Image background;

		/// <summary>
		/// The scroll rect to navigate the content
		/// </summary>
		private ScrollRect scrollRect;

		/// <summary>
		/// The log to display
		/// </summary>
		private Text log;

		/// <summary>
		/// The button to show the log
		/// </summary>
		private Button logButton;

		/// <summary>
		/// If the log is currently showing
		/// </summary>
		private bool showing;

		/// <summary>
		/// The full log.
		/// </summary>
		private static string fullLog;

		/// <summary>
		/// My log queue.
		/// </summary>
		private static Queue myLogQueue = new Queue();

		#endregion // PRIVATE_VARIABLES

		/// <summary>
		/// Awake this instance.
		/// </summary>
		void Awake() {
			AvailableCanvas.AttachToCanvas(transform);

			//Background
			background = gameObject.AddComponent<Image>();
			background.rectTransform.Initialize(bounds);
			background.color = backgroundColor;

			GameObject content = new GameObject();
			content.name = "Log";
			content.transform.SetParent(transform);

			//Log
			log = content.AddComponent<Text>();
			log.InitializeWithDefaultValues(logBounds);
			log.color = Color.white;
			log.resizeTextForBestFit = false;

			scrollRect = gameObject.AddComponent<ScrollRect>();
			scrollRect.content = content.GetComponent<RectTransform>();
			scrollRect.horizontal = false;

			//Button
			logButton = new GameObject().AddComponent<Button>();;
			logButton.name = "Log Button";
			AvailableCanvas.AttachToCanvas(logButton.transform);
			logButton.gameObject.AddComponent<Image>().color = buttonColor;
			logButton.onClick.AddListener(() => Toggle());
			logButton.GetComponent<RectTransform>().Initialize(buttonBounds);
			DragableUI dragable = logButton.gameObject.AddComponent<DragableUI>();

			//Button text
			Text buttonText = new GameObject().AddComponent<Text>();
			buttonText.transform.SetParent(logButton.transform);
			buttonText.InitializeWithDefaultValues(halfRect);
			buttonText.name = "Text";
			buttonText.text = "LOG";
			buttonText.fontStyle = FontStyle.Bold;
			buttonText.alignment = TextAnchor.MiddleCenter;
			buttonText.color = Color.white;

			Application.RegisterLogCallback(HandleLog);

			gameObject.SetActive(false);
		}

		/// <summary>
		/// Handles the log.
		/// </summary>
		/// <param name="logString">Log string.</param>
		/// <param name="stackTrace">Stack trace.</param>
		/// <param name="type">Type.</param>
		private void HandleLog(string logString, string stackTrace, LogType type) {
			string newString = "\n [" + type + "] : " + logString;

			myLogQueue.Enqueue(newString);

			if (type == LogType.Exception) {
				newString = "\n" + stackTrace;
				myLogQueue.Enqueue(newString);
			}

			fullLog = string.Empty;

			foreach (string s in myLogQueue) {
				fullLog += s;
			}

			log.text = fullLog;
		}

		/// <summary>
		/// Toggle this log.
		/// </summary>
		private void Toggle() {
			if (showing) {
				showing = false;
				gameObject.SetActive(false);
			} else {
				showing = true;
				gameObject.SetActive(true);
			}
		}
	}
}