var class_g_p_s_manager =
[
    [ "OnGUI", "class_g_p_s_manager.html#a6900dee86095c191592dcc7230f2c4a1", null ],
    [ "Start", "class_g_p_s_manager.html#abab89e654ad5fb8385d2497e27a6a96b", null ],
    [ "Update", "class_g_p_s_manager.html#a743dea1d8b44136547afcad857c6d00e", null ],
    [ "degrees", "class_g_p_s_manager.html#aacf85f675cd3eb8d0f99d394f470bd00", null ],
    [ "gpsActivityJavaClass", "class_g_p_s_manager.html#af586495843a8952f27235c86ff7a818c", null ],
    [ "userLocation", "class_g_p_s_manager.html#acff0e45c53155606483cc9054aea1f33", null ],
    [ "xValue", "class_g_p_s_manager.html#a99609df2328f567906dbd749be2efd1c", null ],
    [ "yValue", "class_g_p_s_manager.html#a7ea9347dbe3931e81d9993edee505fdb", null ],
    [ "zValue", "class_g_p_s_manager.html#a6db207ef9106087ed3544aaaaae90a8c", null ]
];