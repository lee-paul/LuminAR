var namespaces =
[
    [ "com", "namespacecom.html", "namespacecom" ],
    [ "LuminAR", "namespace_lumin_a_r.html", "namespace_lumin_a_r" ]
];