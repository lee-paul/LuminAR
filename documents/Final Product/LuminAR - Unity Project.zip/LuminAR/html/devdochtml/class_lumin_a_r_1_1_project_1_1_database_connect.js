var class_lumin_a_r_1_1_project_1_1_database_connect =
[
    [ "closeConnections", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a356aaadd07463b6fef90788132e33979", null ],
    [ "deleteLocation", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a1a245a2828d1dc44ba9c69aca2f12d53", null ],
    [ "editLocation", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a70612e913d216358b56ecbc1e796f2dc", null ],
    [ "getDistance", "class_lumin_a_r_1_1_project_1_1_database_connect.html#adb4a70d01209718aba04ff667a11f394", null ],
    [ "insertToDB", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a2b4e9aadb9bf5e6e58f8363287275c6c", null ],
    [ "openDB", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a61335b3864fd4628dcc0bbc00888c232", null ],
    [ "dbcmd", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a7892cf9221030383da0e66bcad5a234b", null ],
    [ "dbconn", "class_lumin_a_r_1_1_project_1_1_database_connect.html#aea273362e9134795113c48898089d900", null ],
    [ "dbDownload", "class_lumin_a_r_1_1_project_1_1_database_connect.html#ab8adfba483dc0f529c33b66212fd329c", null ],
    [ "dbName", "class_lumin_a_r_1_1_project_1_1_database_connect.html#ac8f244c5fec19aa85162cae037e208b0", null ],
    [ "distanceArray", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a7d80f8fa8a0069289d6cfc8878c95756", null ],
    [ "fileLocation", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a57399c3680233d3134b37ff1cb43aaba", null ],
    [ "gps_desc", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a3803139ac173cfc6ed87e4b4fbd210a9", null ],
    [ "gps_id", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a8fb78f93ac2d71786b2ac30ae3b3609d", null ],
    [ "gps_lat", "class_lumin_a_r_1_1_project_1_1_database_connect.html#aef071617567014762856548e743aacc0", null ],
    [ "gpsActivityJavaClass", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a306e11c133fab1e6e49c062b0fc6a961", null ],
    [ "locationID", "class_lumin_a_r_1_1_project_1_1_database_connect.html#afcb6b535bf4ecb303f90d75b2160e9ae", null ],
    [ "maxDistance", "class_lumin_a_r_1_1_project_1_1_database_connect.html#ac43b171163a815dc433ecc155dc690b6", null ],
    [ "reader", "class_lumin_a_r_1_1_project_1_1_database_connect.html#aab7ca53987e94129e9f0ab686e8703f4", null ],
    [ "tableName", "class_lumin_a_r_1_1_project_1_1_database_connect.html#a17c0e3616c5e305bb6632bb73d977710", null ]
];