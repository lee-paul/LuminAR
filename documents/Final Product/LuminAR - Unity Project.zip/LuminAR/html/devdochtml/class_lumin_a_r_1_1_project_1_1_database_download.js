var class_lumin_a_r_1_1_project_1_1_database_download =
[
    [ "Start", "class_lumin_a_r_1_1_project_1_1_database_download.html#ad9dc9780ca5628cbb61a67dcd1ec875e", null ],
    [ "fileLocation", "class_lumin_a_r_1_1_project_1_1_database_download.html#af95df66911c88c9726154f267e0a886f", null ],
    [ "url", "class_lumin_a_r_1_1_project_1_1_database_download.html#a2c00eaab048068bcc6fc271294cd38da", null ],
    [ "www", "class_lumin_a_r_1_1_project_1_1_database_download.html#a7db41d859bd7cf58918e3e952f5845de", null ]
];