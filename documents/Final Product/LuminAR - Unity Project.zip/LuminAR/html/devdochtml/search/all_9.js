var searchData=
[
  ['maxdistance',['maxDistance',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#ac43b171163a815dc433ecc155dc690b6',1,'LuminAR::Project::DatabaseConnect']]],
  ['mlistener',['mListener',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#aa6af3afbb75842e4475ea2f5c86d836b',1,'com::LuminAR::Project::GPSLocation']]],
  ['msensor',['mSensor',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#a2b584f1c5d93efd149adb32a53a66b5b',1,'com::LuminAR::Project::GPSLocation']]],
  ['msensormanager',['mSensorManager',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#a9a4fd6ba238852346e3e0dd2cab153c3',1,'com::LuminAR::Project::GPSLocation']]],
  ['mylocationmanager',['myLocationManager',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#a02b1c61aac788bc4fbc3702ad2a1f6e7',1,'com::LuminAR::Project::GPSLocation']]]
];
