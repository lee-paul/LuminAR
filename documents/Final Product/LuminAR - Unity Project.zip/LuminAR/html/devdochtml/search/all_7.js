var searchData=
[
  ['inserttodb',['insertToDB',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a2b4e9aadb9bf5e6e58f8363287275c6c',1,'LuminAR::Project::DatabaseConnect']]]
];
