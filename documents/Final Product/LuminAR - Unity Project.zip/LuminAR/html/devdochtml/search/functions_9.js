var searchData=
[
  ['update',['Update',['../class_g_p_s_manager.html#a743dea1d8b44136547afcad857c6d00e',1,'GPSManager']]]
];
