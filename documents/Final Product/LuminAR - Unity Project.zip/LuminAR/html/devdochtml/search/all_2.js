var searchData=
[
  ['databaseconnect',['DatabaseConnect',['../class_lumin_a_r_1_1_project_1_1_database_connect.html',1,'LuminAR::Project']]],
  ['databaseconnect_2ecs',['DatabaseConnect.cs',['../_database_connect_8cs.html',1,'']]],
  ['databasedownload',['DatabaseDownload',['../class_lumin_a_r_1_1_project_1_1_database_download.html',1,'LuminAR::Project']]],
  ['databasedownload_2ecs',['DatabaseDownload.cs',['../_database_download_8cs.html',1,'']]],
  ['databasefunctions',['DatabaseFunctions',['../class_lumin_a_r_1_1_project_1_1_database_functions.html',1,'LuminAR::Project']]],
  ['databasefunctions_2ecs',['DatabaseFunctions.cs',['../_database_functions_8cs.html',1,'']]],
  ['db',['db',['../class_lumin_a_r_1_1_project_1_1_database_functions.html#a332d2655065c510aac2328048c12d425',1,'LuminAR::Project::DatabaseFunctions']]],
  ['dbcmd',['dbcmd',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a7892cf9221030383da0e66bcad5a234b',1,'LuminAR::Project::DatabaseConnect']]],
  ['dbconn',['dbconn',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#aea273362e9134795113c48898089d900',1,'LuminAR::Project::DatabaseConnect']]],
  ['dbdownload',['dbDownload',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#ab8adfba483dc0f529c33b66212fd329c',1,'LuminAR::Project::DatabaseConnect']]],
  ['dbname',['dbName',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#ac8f244c5fec19aa85162cae037e208b0',1,'LuminAR::Project::DatabaseConnect']]],
  ['degrees',['degrees',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#aefd9cf4a3e1454db5602fcccb21ad53a',1,'com.LuminAR.Project.GPSLocation.degrees()'],['../class_g_p_s_manager.html#aacf85f675cd3eb8d0f99d394f470bd00',1,'GPSManager.degrees()']]],
  ['delete_5fedit_5fgps_5fid',['delete_edit_gps_id',['../class_lumin_a_r_1_1_project_1_1_database_functions.html#ababdf447bb2e850a4638f0ad466a6e77',1,'LuminAR::Project::DatabaseFunctions']]],
  ['deletelocation',['deleteLocation',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#ab26b775ef81af62bc7e8d1e8161b0d03',1,'com.LuminAR.Project.GPSLocation.deleteLocation()'],['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a1a245a2828d1dc44ba9c69aca2f12d53',1,'LuminAR.Project.DatabaseConnect.deleteLocation()']]],
  ['distancearray',['distanceArray',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a7d80f8fa8a0069289d6cfc8878c95756',1,'LuminAR::Project::DatabaseConnect']]]
];
