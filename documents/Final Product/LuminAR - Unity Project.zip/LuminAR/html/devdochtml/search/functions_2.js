var searchData=
[
  ['deletelocation',['deleteLocation',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#ab26b775ef81af62bc7e8d1e8161b0d03',1,'com.LuminAR.Project.GPSLocation.deleteLocation()'],['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a1a245a2828d1dc44ba9c69aca2f12d53',1,'LuminAR.Project.DatabaseConnect.deleteLocation()']]]
];
