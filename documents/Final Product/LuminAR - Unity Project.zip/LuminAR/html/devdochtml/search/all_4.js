var searchData=
[
  ['filelocation',['fileLocation',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a57399c3680233d3134b37ff1cb43aaba',1,'LuminAR.Project.DatabaseConnect.fileLocation()'],['../class_lumin_a_r_1_1_project_1_1_database_download.html#af95df66911c88c9726154f267e0a886f',1,'LuminAR.Project.DatabaseDownload.fileLocation()']]]
];
