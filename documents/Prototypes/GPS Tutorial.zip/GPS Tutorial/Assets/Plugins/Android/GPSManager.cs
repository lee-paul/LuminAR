﻿using UnityEngine;
using System.Collections;
/** Accessing the GPS Data over JNI calls
 *  Please check the Java sources under Plugins/Android
 * */
public class GPSManager : MonoBehaviour {
	static string locationMessage;
	static float distanceMessage;
	static string accuracyMessage;
	AndroidJavaClass gpsActivityJavaClass;

	void Start () {
		AndroidJNI.AttachCurrentThread();
		gpsActivityJavaClass = new AndroidJavaClass("com.test.app.GPSTest");
	}
	void Update() {
		locationMessage = gpsActivityJavaClass.CallStatic<string>("getLocation");
		distanceMessage = gpsActivityJavaClass.CallStatic<float> ("getDistance");
		accuracyMessage = gpsActivityJavaClass.CallStatic<string> ("getAccuracy");
		string location = "";
		GUIText setText;

		location = locationMessage;
		setText = GameObject.Find("gps_output").GetComponent<GUIText>();
		setText.text  = location;


		location = "" + distanceMessage;
		setText = GameObject.Find("gps_skytower").GetComponent<GUIText>();
      	setText.text = "Distance from SkyTower = " + location;

		location = accuracyMessage;
		setText = GameObject.Find ("gps_accuracy").GetComponent<GUIText> ();
		setText.text = location;

	}	
}