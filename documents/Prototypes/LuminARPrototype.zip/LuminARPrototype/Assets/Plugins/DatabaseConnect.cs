﻿using UnityEngine;
using System.Collections;
using Mono.Data.Sqlite;
using System.Data;
using System;

namespace LuminAR.Project{

	public class DatabaseConnect {

		[Header("Database Name")]
		public string dbName = "gpsnodes.sqlite";

		[Header("Table Name")]
		public string tableName = "nodes";

		[Header("Table Name")]
		// Can set a location to load the database from elsewhere.
		public string fileLocation; //Application.dataPath

		// Use this for initialization
		public void connecToDB () {
			int gps_id;
			float gps_lat;
			float gps_long;
			string gps_desc;

			string conn = "URI=file:" + Application.persistentDataPath + "/" + dbName; //Path to database.
			IDbConnection dbconn;

			dbconn = (IDbConnection)new SqliteConnection (conn);
			dbconn.Open (); //Open connection to the database.

			//Check the connect to the database is made.
			if (dbconn != null && dbconn.State == ConnectionState.Open) {
				Debug.Log("Connection Success!");
				IDbCommand dbcmd = dbconn.CreateCommand ();
				string sqlQuery = "SELECT * FROM " + tableName;
				dbcmd.CommandText = sqlQuery;
				IDataReader reader = dbcmd.ExecuteReader ();

				//Read the contents of the database.
				while (reader.Read()) {
					gps_id = reader.GetInt32 (0);
					gps_lat = reader.GetFloat (1);
					gps_long = reader.GetFloat (2);
					gps_desc = reader.GetString (3);
				
					//Print the contents (nodes) inside the database.
					/*Debug.Log ("GPS Node Details: "
					           + Environment.NewLine + "GPS ID: " + gps_id
					           + Environment.NewLine + "GPS Latitude: " + gps_lat 
					           + Environment.NewLine + "GPS Longitude: " + gps_long
					           + Environment.NewLine + "GPS Description: " + gps_desc);*/
					GameObject.Find ("gps_locations").GetComponent<GUIText>().text = ("GPS Node Details: "
					                                          + "\nGPS ID: " + gps_id
					                                          + "\nGPS Latitude: " + gps_lat 
					                                          + "\nGPS Longitude: " + gps_long
					                                          + "\nGPS Description: " + gps_desc);
				
				}
				reader.Close ();
				reader = null;
				dbcmd.Dispose ();
				dbcmd = null;
				dbconn.Close ();
				dbconn = null;
			} else {
				Debug.Log ("Error - Could not connect to Database!");
			}
		}
		// Update is called once per frame
		void Update () {
			
		}
	}
}
