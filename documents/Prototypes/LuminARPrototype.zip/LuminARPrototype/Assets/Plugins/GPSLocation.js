﻿  /* GPS Variables */
 var lat : float = 0;        //lattitude , longitude and altitude variables
 var lon : float = 0;
 var alt : float = 0;
 var accuracy : int =10;    //accuracy of the GPS module in m
 var distance : int = 10;    // minimum distance before next location variables allocation
 var maxWait : int = 20;    //maximum time (s) before time out
 var locationStatus : int =0;        
     
 
 function Start () 
 {
     Input.location.Start();                    //enable location settings
     Input.compass.enabled = true;
     locationStatus = LocationServiceStatus.Stopped;
 
     startLocationService();                     //begin GPS transmittion
 }
 
 function Update () 
 {
    if(locationStatus == LocationServiceStatus.Running)
     {
         
         lat = Input.location.lastData.latitude;
         lon = Input.location.lastData.longitude;
         alt = Input.location.lastData.altitude;
         
         //print(lat);
         //print(lon);
         //print(alt);
 GUI.Box(Rect(Screen.width - 200,Screen.height - 50, 100,50), "Latitude => " +lat + "\n Longitude => " + lon + "\n Altitude => "  +alt );
        
     } 
 }
 
 
 function startLocationService()
 {
     Input.location.Start(accuracy, distance);
     
 
     while(Input.location.status == LocationServiceStatus.Initializing && maxWait > 0) 
     {
         WaitForSeconds(1);
         maxWait--;
        locationStatus = Input.location.status;
     }
 } 