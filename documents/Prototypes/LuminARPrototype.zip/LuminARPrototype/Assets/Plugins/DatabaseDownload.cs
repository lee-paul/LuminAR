﻿using UnityEngine;
using System;
using System.Text;
using System.Collections;
using System.IO;
using System.Net;

namespace LuminAR.Project{

	public class DatabaseDownload : MonoBehaviour {

		[Header("Table Name")]
		// This can be used to download the file elsewhere.
		public string fileLocation; //Application.dataPath
		public string url = "http://www.nzwheelsonline.com/AHCI/gpsnodes.sqlite";

		// Use this for initialization
		//void Start () {
		//	download ();
		//}

		IEnumerator Start(){
			WWW www = new WWW ("http://www.nzwheelsonline.com/AHCI/gpsnodes.sqlite");

			while (!www.isDone) {
				Debug.Log ("downloaded " + (www.progress*100).ToString() + "%...");
				yield return null;
			}
			Debug.Log ("Download Complete");
			string fullPath = Application.persistentDataPath + "/gpsnodes.sqlite";
			Debug.Log (Application.persistentDataPath);
			File.WriteAllBytes (fullPath, www.bytes);

				DatabaseConnect dbConnect = new DatabaseConnect ();
				dbConnect.connecToDB ();
		}

		void Update(){


		}
	}
}