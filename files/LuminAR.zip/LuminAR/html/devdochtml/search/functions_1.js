var searchData=
[
  ['closeconnections',['closeConnections',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a356aaadd07463b6fef90788132e33979',1,'LuminAR::Project::DatabaseConnect']]],
  ['createlocation',['createLocation',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#aead49631012517461c4a732825717de3',1,'com::LuminAR::Project::GPSLocation']]]
];
