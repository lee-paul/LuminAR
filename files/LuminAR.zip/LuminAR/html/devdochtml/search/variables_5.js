var searchData=
[
  ['gps_5fdesc',['gps_desc',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a3803139ac173cfc6ed87e4b4fbd210a9',1,'LuminAR.Project.DatabaseConnect.gps_desc()'],['../class_lumin_a_r_1_1_project_1_1_database_functions.html#af69fae2fd54b98e45ee84cdf6e82a5c6',1,'LuminAR.Project.DatabaseFunctions.gps_desc()']]],
  ['gps_5fid',['gps_id',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a8fb78f93ac2d71786b2ac30ae3b3609d',1,'LuminAR::Project::DatabaseConnect']]],
  ['gps_5flat',['gps_lat',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#aef071617567014762856548e743aacc0',1,'LuminAR.Project.DatabaseConnect.gps_lat()'],['../class_lumin_a_r_1_1_project_1_1_database_functions.html#afc0138200fa19bd069147701b4a7c672',1,'LuminAR.Project.DatabaseFunctions.gps_lat()']]],
  ['gps_5flong',['gps_long',['../class_lumin_a_r_1_1_project_1_1_database_functions.html#a512ef56a202c09b0b5e103bdfbae5c7f',1,'LuminAR::Project::DatabaseFunctions']]],
  ['gpsactivityjavaclass',['gpsActivityJavaClass',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#a306e11c133fab1e6e49c062b0fc6a961',1,'LuminAR.Project.DatabaseConnect.gpsActivityJavaClass()'],['../class_g_p_s_manager.html#af586495843a8952f27235c86ff7a818c',1,'GPSManager.gpsActivityJavaClass()']]],
  ['gpslocationlistener',['gpsLocationListener',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#a5a2ed9b8524fe1811b98d45a2962ffbd',1,'com::LuminAR::Project::GPSLocation']]]
];
