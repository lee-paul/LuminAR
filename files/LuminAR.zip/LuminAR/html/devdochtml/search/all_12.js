var searchData=
[
  ['ymag',['ymag',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#a00cb85c5cd88fe21120c35bf6aebd1a0',1,'com::LuminAR::Project::GPSLocation']]],
  ['yvalue',['yValue',['../class_g_p_s_manager.html#a7ea9347dbe3931e81d9993edee505fdb',1,'GPSManager']]]
];
