var searchData=
[
  ['xmag',['xmag',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#ab5c662d0e4fb14a1dee8ce32fd676b48',1,'com::LuminAR::Project::GPSLocation']]],
  ['xvalue',['xValue',['../class_g_p_s_manager.html#a99609df2328f567906dbd749be2efd1c',1,'GPSManager']]]
];
