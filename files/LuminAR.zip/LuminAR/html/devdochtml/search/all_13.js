var searchData=
[
  ['zmag',['zmag',['../classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html#ae499bb6065c43d96a052981086fb68e4',1,'com::LuminAR::Project::GPSLocation']]],
  ['zvalue',['zValue',['../class_g_p_s_manager.html#a6db207ef9106087ed3544aaaaae90a8c',1,'GPSManager']]]
];
