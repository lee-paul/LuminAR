var searchData=
[
  ['reader',['reader',['../class_lumin_a_r_1_1_project_1_1_database_connect.html#aab7ca53987e94129e9f0ab686e8703f4',1,'LuminAR::Project::DatabaseConnect']]]
];
