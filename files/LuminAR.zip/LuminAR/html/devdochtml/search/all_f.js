var searchData=
[
  ['update',['Update',['../class_g_p_s_manager.html#a743dea1d8b44136547afcad857c6d00e',1,'GPSManager']]],
  ['url',['url',['../class_lumin_a_r_1_1_project_1_1_database_download.html#a2c00eaab048068bcc6fc271294cd38da',1,'LuminAR::Project::DatabaseDownload']]],
  ['userlocation',['userLocation',['../class_g_p_s_manager.html#acff0e45c53155606483cc9054aea1f33',1,'GPSManager']]]
];
