var hierarchy =
[
    [ "LuminAR.Project.DatabaseConnect", "class_lumin_a_r_1_1_project_1_1_database_connect.html", null ],
    [ "MonoBehaviour", null, [
      [ "GPSManager", "class_g_p_s_manager.html", null ],
      [ "LuminAR.Project.DatabaseDownload", "class_lumin_a_r_1_1_project_1_1_database_download.html", null ],
      [ "LuminAR.Project.DatabaseFunctions", "class_lumin_a_r_1_1_project_1_1_database_functions.html", null ]
    ] ],
    [ "UnityPlayerActivity", null, [
      [ "com.LuminAR.Project.GPSLocation", "classcom_1_1_lumin_a_r_1_1_project_1_1_g_p_s_location.html", null ]
    ] ]
];