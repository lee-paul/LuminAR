var namespace_lumin_a_r_1_1_project =
[
    [ "DatabaseConnect", "class_lumin_a_r_1_1_project_1_1_database_connect.html", "class_lumin_a_r_1_1_project_1_1_database_connect" ],
    [ "DatabaseDownload", "class_lumin_a_r_1_1_project_1_1_database_download.html", "class_lumin_a_r_1_1_project_1_1_database_download" ],
    [ "DatabaseFunctions", "class_lumin_a_r_1_1_project_1_1_database_functions.html", "class_lumin_a_r_1_1_project_1_1_database_functions" ]
];