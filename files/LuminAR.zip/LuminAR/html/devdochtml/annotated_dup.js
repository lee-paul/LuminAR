var annotated_dup =
[
    [ "com", "namespacecom.html", "namespacecom" ],
    [ "LuminAR", "namespace_lumin_a_r.html", "namespace_lumin_a_r" ],
    [ "GPSManager", "class_g_p_s_manager.html", "class_g_p_s_manager" ]
];