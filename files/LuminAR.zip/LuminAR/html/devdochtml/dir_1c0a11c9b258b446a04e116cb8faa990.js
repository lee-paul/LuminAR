var dir_1c0a11c9b258b446a04e116cb8faa990 =
[
    [ "android", "dir_fbad0b67197010ac820d4d93674f19ab.html", "dir_fbad0b67197010ac820d4d93674f19ab" ],
    [ "DatabaseConnect.cs", "_database_connect_8cs.html", [
      [ "DatabaseConnect", "class_lumin_a_r_1_1_project_1_1_database_connect.html", "class_lumin_a_r_1_1_project_1_1_database_connect" ]
    ] ],
    [ "DatabaseDownload.cs", "_database_download_8cs.html", [
      [ "DatabaseDownload", "class_lumin_a_r_1_1_project_1_1_database_download.html", "class_lumin_a_r_1_1_project_1_1_database_download" ]
    ] ],
    [ "DatabaseFunctions.cs", "_database_functions_8cs.html", [
      [ "DatabaseFunctions", "class_lumin_a_r_1_1_project_1_1_database_functions.html", "class_lumin_a_r_1_1_project_1_1_database_functions" ]
    ] ],
    [ "GPSManager.cs", "_g_p_s_manager_8cs.html", [
      [ "GPSManager", "class_g_p_s_manager.html", "class_g_p_s_manager" ]
    ] ]
];