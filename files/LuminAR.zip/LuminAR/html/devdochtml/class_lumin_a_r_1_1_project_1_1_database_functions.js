var class_lumin_a_r_1_1_project_1_1_database_functions =
[
    [ "Awake", "class_lumin_a_r_1_1_project_1_1_database_functions.html#a5f03a8115248d142f64de403ef887a56", null ],
    [ "hide", "class_lumin_a_r_1_1_project_1_1_database_functions.html#a288c897dec496960b7ece2eda9d9881e", null ],
    [ "OnGUI", "class_lumin_a_r_1_1_project_1_1_database_functions.html#aa96771069af9d2fc85f4c2737ccefbac", null ],
    [ "db", "class_lumin_a_r_1_1_project_1_1_database_functions.html#a332d2655065c510aac2328048c12d425", null ],
    [ "delete_edit_gps_id", "class_lumin_a_r_1_1_project_1_1_database_functions.html#ababdf447bb2e850a4638f0ad466a6e77", null ],
    [ "edit_gps_desc", "class_lumin_a_r_1_1_project_1_1_database_functions.html#ad3019a5a3fb41ed507e9f78a0b79509e", null ],
    [ "edit_gps_id", "class_lumin_a_r_1_1_project_1_1_database_functions.html#a323f80369870121ec709856a30383d4a", null ],
    [ "edit_gps_lat", "class_lumin_a_r_1_1_project_1_1_database_functions.html#ac4fb2545405c6e27952afa0761ee7f68", null ],
    [ "edit_gps_long", "class_lumin_a_r_1_1_project_1_1_database_functions.html#a7a55551450ceee58f1c47f03e08a2a55", null ],
    [ "gps_desc", "class_lumin_a_r_1_1_project_1_1_database_functions.html#af69fae2fd54b98e45ee84cdf6e82a5c6", null ],
    [ "gps_lat", "class_lumin_a_r_1_1_project_1_1_database_functions.html#afc0138200fa19bd069147701b4a7c672", null ],
    [ "gps_long", "class_lumin_a_r_1_1_project_1_1_database_functions.html#a512ef56a202c09b0b5e103bdfbae5c7f", null ],
    [ "hidden", "class_lumin_a_r_1_1_project_1_1_database_functions.html#a05dff862e2a2424388f59bd7c9320ba6", null ]
];