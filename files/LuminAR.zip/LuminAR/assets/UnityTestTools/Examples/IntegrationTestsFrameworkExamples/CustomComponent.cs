using System;
using System.Collections.Generic;
using UnityEngine;

namespace UnityTest
{
    public class CustomComponent : MonoBehaviour
    {
        public float MyFloatProp { get; set; }
        public float MyFloatField = 3;
    }
}
